#include <iostream> 
using namespace std; 
struct tnode 
{ 
 int data; 
 tnode *left,*right; 
}; 
class BST 
{ 
 tnode *nn; 
 public : 
 tnode *root; 
 BST() 
{ 
 root = NULL; 
} 
void insert(); 
void inorder(tnode *root); 
void preorder(tnode *root); 
void postorder(tnode *root); 
void search(); 
void deletion(int key); 
}; 
void BST::insert() 
{ 
 nn = new tnode; 
 cout<<"Enter data = "; 
 cin>>nn->data; 
 nn->left = nn->right = NULL; 
 if(root == NULL) 
 { 
 root = nn; 
 } 
 else 
 { 
 tnode *temp = root,*parent = NULL; 
 while(temp != NULL) 
 { 
 parent = temp; 
 if(nn->data < temp->data) 
 { 
 temp = temp->left; 
 } 
 else 
 { 
 temp = temp->right; 
 } 
 } 
 if(nn->data < parent->data) 
 { 
 parent->left = nn; 
 } 
 else 
 { 
 parent->right = nn; 
 } 
 } 
 cout<<endl; 
} 
void BST::inorder(tnode *root) 
{ 
 tnode *temp = root; 
 if(temp != NULL) 
 { 
 inorder(temp->left); 
 cout<<temp->data<<" "; 
 inorder(temp->right); 
 } 
} 
void BST::preorder(tnode *root) 
{ 
 tnode *temp = root; 
 if(temp != NULL) 
 { 
 cout<<temp->data<<" "; 
 inorder(temp->left); 
 inorder(temp->right); 
 } 
} 
void BST::postorder(tnode *root) 
{ 
 tnode *temp = root; 
 if(temp != NULL) 
 { 
 inorder(temp->left); 
 inorder(temp->right); 
 cout<<temp->data<<" "; 
 } 
} 
void BST::search() 
{ 
 int key; 
 tnode *temp = root; 
 cout<<"Enter key to search = "; 
 cin>>key; 
 while(temp != NULL) 
 { 
 if(key == temp->data) 
 { 
 break; 
 } 
 else 
 { 
 if(key<temp->data) 
 { 
 temp = temp->left; 
 } 
 else 
 { 
 temp = temp->right; 
 } 
 } 
 } 
 if(temp == NULL) 
 { 
 cout<<"Key is not found "<<endl<<endl; 
 } 
 else 
 { 
 cout<<"Key is found = "<<temp->data<<endl<<endl; 
 } 
} 
void BST::deletion(int key) 
{ 
 tnode *temp = root,*parent = NULL; 
 while(temp != NULL) 
 { 
 if(key == temp->data) 
 { 
 break; 
 } 
 else 
 { 
 parent = temp; 
 if(key<temp->data) 
 { 
 temp = temp->left; 
 } 
 else 
 { 
 temp = temp->right; 
 } 
 } 
 } 
 if(temp == NULL) 
 { 
 cout<<"Key is not found "<<endl<<endl; 
 } 
 else 
 { 
 //Node with no child 
 if(temp->left==NULL && temp->right==NULL) 
 { 
 if(root == temp) 
 { 
 root = NULL; 
 cout<<"Tree Is Empty\n"<<endl; 
 return; 
 } 
 if(temp->data < parent->data) 
 { 
 parent->left = NULL; 
 } 
 else 
 { 
 parent->right = NULL; 
 } 
 delete temp; 
 } 
 //Node with left child 
 else if(temp->left!=NULL && temp->right==NULL) 
 { 
 if(root == temp) 
 { 
 root = temp->left; 
 delete temp; 
 } 
 else 
 { 
 if(temp->left->data < parent->data) 
 { 
 parent->left = temp->left; 
 } 
 else 
 { 
 parent->right = temp->left; 
 } 
 delete temp; 
 } 
 } 
 //Node with right child 
 else if(temp->left==NULL && temp->right!=NULL) 
 { 
 if(root == temp) 
 { 
 root = temp->right; 
 delete temp; 
 } 
 else 
 { 
 if(temp->right->data < parent->data) 
 {if(temp == NULL) 
 { 
 cout<<"Key is not found "<<endl<<endl; 
 } 
 parent->left = temp->right; 
 } 
 else 
 { 
 parent->right = temp->right; 
 } 
 delete temp; 
 } 
 } 
 //Node with two childs 
 else 
 { 
 int val; 
 tnode *successor = temp->right; 
 while(successor->left != NULL) 
 { 
 successor = successor->left; 
 } 
 val = successor->data; 
 deletion(val); 
 temp->data = val; } } } 
int main() { 
 BST Obj; 
 int ch,key; 
 cout<<"Enter 1 to insert\nEnter 2 for inorder traversal\nEnter 3 for preorder traversal\nEnter 4 for postorder traversal\nEnter 5 to search a node\nEnter 6 to delete a node"<<endl; 
 while(1) { 
 cout<<"Enter the choice = "; 
 cin>>ch; 
 switch(ch) { 
 case 1: Obj.insert(); 
 break; 
 case 2: cout<<"Inorder traversal is "; 
 Obj.inorder(Obj.root); 
 cout<<endl<<endl; 
 break; 
 case 3: cout<<"Preorder traversal is "; 
 Obj.preorder(Obj.root); 
 cout<<endl<<endl; 
 break; 
 case 4: cout<<"Postorder traversal is "; 
 Obj.postorder(Obj.root); 
 cout<<endl<<endl; 
 break; 
 case 5: Obj.search(); 
 break; 
 case 6: cout<<"Enter key to delete = "; 
 cin>>key; 
 Obj.deletion(key); 
 cout<<endl; 
 break; } } } 