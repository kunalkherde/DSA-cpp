#include <iostream> 
#include <cstring> 
#include <iomanip> 
using namespace std; 
const int size = 5; //size of hash table 
const int no_of_employee = 3; 
class ehash 
{ 
char name[size][20]; 
long int contact[size]; 
int status[size]; 
public: 
 void insertion_by_quadratic(); 
 void insertion_by_linear(); 
 void display(); 
 void search_linear(); 
 void search_quadratic(); 
ehash() 
{ 
 int i; 
 for(i=0;i<size;i++) 
 { 
 strcpy(name[i],"-----"); 
 contact[i] = 0; 
 status[i] = 0; 
 } 
} 
}; 
void ehash::insertion_by_linear() 
{ 
 char tname[size][20]; 
 long int tcontact[size]; 
 int loc,i,j; 
 for(i=0;i<no_of_employee;i++) 
 { 
 cout<<"Enter the data of employee "<<i+1<<endl; 
 cout<<"Name = "; 
 cin>>tname[i]; 
 cout<<"contact = "; 
 cin>>tcontact[i]; 
 loc = tcontact[i]%size; 
 for(j=0;j<size;j++) 
 { 
 if(status[loc]==0) 
 { 
 strcpy(name[loc],tname[i]); 
 contact[loc]=tcontact[i]; 
 status[loc]=1; 
 break; 
 } 
 loc=(loc+1)%size; 
 } 
 } 
} 
void ehash::insertion_by_quadratic() 
{ 
 char tname[size][20]; 
 long int tcontact[size]; 
 int loc,i,j; 
 for(i=0;i<no_of_employee;i++) 
 { 
 cout<<"Enter the data of employee "<<i+1<<endl; 
 cout<<"Name = "; 
 cin>>tname[i]; 
 cout<<"contact = "; 
 cin>>tcontact[i]; 
 loc = tcontact[i]%size; 
 for(j=1;j<size;j++) 
 { 
 if(status[loc]==0) 
 { 
 strcpy(name[loc],tname[i]); 
 contact[loc]=tcontact[i]; 
 status[loc]=1; 
 break; 
 } 
 loc=(loc+j*j)%size; 
 } 
 } 
} 
void ehash::display() 
{ 
 int i; 
cout<<endl; 
cout<<setw(5)<<"Index"<<setw(10)<<"Name"<<setw(12)<<"contact"<<setw(12)<<"status"<<endl; 
 for(i=0;i<size;i++) 
{ 
cout<<setw(5)<<i<<setw(10)<<name[i]<<setw(12)<<contact[i]<<setw(12)<<status[i]<<endl; 
 } 
 cout<<"-------------------------------"<<endl; 
} 
void ehash::search_linear() 
{ 
 long int tcontact; 
 int loc; 
 cout<<"Enter contact number of the employee to be searched = "; 
 cin>>tcontact; 
 loc=tcontact%size; 
 while(contact[loc]!=tcontact) 
 { 
 loc=(loc+1)%size; 
 } 
 cout<<"Name = "<<name[loc]<<endl; 
 cout<<"Contact = "<<contact[loc]<<endl; 
 cout<<"-------------------------------"<<endl; 
} 
void ehash::search_quadratic() 
{ 
 long int tcontact; 
 int loc,i=1; 
 cout<<"Enter contact number of the employee to be searched = "; 
 cin>>tcontact; 
 loc=tcontact%size; 
 while(contact[loc]!=tcontact) 
 { 
 loc=(loc+i*i)%size; 
 i++; 
 } 
 cout<<"Name = "<<name[loc]<<endl; 
 cout<<"Contact = "<<contact[loc]<<endl; 
 cout<<"-------------------------------"<<endl; 
} 
int main() { 
    ehash o1,o2; 
    int ch; 
    while(1) 
    { 
    cout<<"Enter 1 for linear probing \n"<<endl<<"Enter 2 for quadratic probing\n"<<endl<<"Enter 3 for searching data in object 1(Linear probing)\n"<<endl<<"Enter 4 for searching data in object 2(Quadratic probing)\n"<<endl; 
    cout<<"Enter choice = "; 
    cin>>ch; 
    cout<<"------------------------------------------------------------------"<<endl; 
    switch(ch) 
    { 
        case 1 : 
        o1.insertion_by_linear(); 
        o1.display(); 
        break; 
        case 2 : 
        o2.insertion_by_quadratic(); 
        o2.display(); 
        break; 
        case 3 : 
        o1.search_linear(); 
        break; 
        case 4 : 
        o2.search_quadratic(); 
        break; 
    } 
} 
 return 0; 
} 
 
 