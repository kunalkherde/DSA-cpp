#include <iostream> 
using namespace std; 
class spanning_tree 
{ 
 public : 
 int n,e,E; // n = no of verices , e = no of edges of graph 
 // E = no of edges of MST 
 int cost[10][10],Adj_matrix[10][10]; 
 int dist[10],visited[10],source[10],spantree[10][10]; 
 int mincost; 
 void insert_graph(); 
 void min_span_tree(); 
}; 
void spanning_tree::insert_graph() 
{ 
 int v1,v2,length; 
 cout<<"Enter the graph :"<<endl; 
 cout<<"Enter no of vertices = "; 
 cin>>n; 
 cout<<"Enter no of edges = "; 
 cin>>e; 
 cout<<endl; 
 for(int i=0;i<n;i++) 
 { 
 for(int j=0;j<n;j++) 
 { 
 Adj_matrix[i][j] = 0; 
 spantree[i][j] = 0; } } 
 for(int i=0;i<e;i++) 
 { 
 cout<<"Enter the edge :"<<endl; 
 cout<<"Startvertex = "; 
 cin>>v1; 
 cout<<"Endvertex = "; 
 cin>>v2; 
 cout<<"Enter the length = "; 
 cin>>length; 
 Adj_matrix[v1][v2] = Adj_matrix[v2][v1] = length; 
 cout<<endl; } } 
void spanning_tree::min_span_tree(){ 
 int i,j,v1,v2,mindistance; 
 // Create cost matrix 
 for(i=0;i<n;i++) { 
 for(j=0;j<n;j++){ 
 if(Adj_matrix[i][j] == 0) { 
 cost[i][j] = 99; // 99 is infinity
} 
 else { 
 cost[i][j] = Adj_matrix[i][j]; } } } 
 // Start from vertex 0 
 dist[0] = source[0] = 0; 
 visited[0] = 1; 
 // calculating distances of all vertices from 0 
 for(i=1;i<n;i++) { 
 source[i] = 0; 
 dist[i] = cost[0][i]; 
 visited[i] = 0; 
 } 
 E = n - 1; // no of edges for MST 
 mincost = 0; 
 while(E>0) 
 { 
 mindistance = 99; 
 // find edge with minimum length 
 for(i=1;i<n;i++) 
 { 
 if(visited[i]==0 && dist[i]<mindistance) 
 { 
 mindistance = dist[i]; 
 v2 = i; } } 
 // add the minimum edge in MST 
 v1 = source[v2]; 
 spantree[v1][v2] = spantree[v2][v1] = dist[v2]; 
 visited[v2] = 1; 
 E--; // Edge is added in MST 
 for(i=1;i<n;i++) { 
 if(visited[i]==0 && cost[v2][i]<dist[i]) { 
 dist[i] = cost[v2][i]; 
 source[i] = v2; } } 
 mincost = mincost + cost[v1][v2]; }} 
int main(){ 
 spanning_tree T; 
 T.insert_graph(); 
 cout<<endl<<"---------------------------------------------------------------"<<endl; 
 T.min_span_tree(); 
 cout<<endl<<"Minimum spanning tree is : "<<endl; 
 for(int i = 0 ; i < T.n ; i++) { 
 for(int j = 0 ; j < T.n ; j++) { 
 cout<<T.spantree[i][j]<<" "; } 
 cout<<endl; } 
 cout<<"Path cost of minimum spanning tree = "<<T.mincost; 
 return 0; 
} 