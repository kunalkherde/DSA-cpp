#include<iostream>
using namespace std;

struct node
{
    int data;
    node*next;

};
class NODE{
    
    node*nn;
    public:
    node*head;

    NODE(){
        head=NULL;

    }

    void insert(){
        int n, count=0;
        node*cn;

        cout<<"Enter the positiion to inser a node=";
        cin>>n;
        cn=head;

        while (cn!=NULL)
        {
            count++;

            cn=cn->next;
        }
        
        if(n==1){
            nn=new node;
            cout<<"Enter the data ";

            cin>>nn->data;
            nn->next=head;
            head=nn;
        }
        else if(n==count+1){
            nn=new node;
            cout<<"Enter the data ";
            cin>>nn->data;
            nn->next=NULL;
            if(head==NULL){
                head=nn;
            }
            else{
                node*cn;
                cn=head;
            }

        }


        
    }

};
