#include<stdio.h>
#include<conio.h>
void main() {
    int n, arr[5];
    int num = 10;
    for(int i = 0; i < num ; i++ ) {
        printf("%d \n",arr[i]);

    }
    int temp =0;
    int n = num - 1;

    for (int i = 0; i < num; i++)
    {
        if ( i > n || i == n) {
            break;
        }
        int temp = arr[n];
        arr[n] = arr[i];
        arr[i] = temp;
        n = n - 1;
    }
    

    printf("After Reverse\n");

    for (int i = 0; i < num; i++)
    {
        printf("\n%d",arr[i]);
    }
    


}

