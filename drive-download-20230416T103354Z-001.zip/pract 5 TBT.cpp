#include <iostream> 
using namespace std; 
struct tnode{ 
 int data; 
 tnode *left,*right; 
 int lth,rth; 
}; 
class TBT{ 
tnode *nn; 
public : 
tnode *root,*dummy; 
TBT(){ 
 root = NULL; 
 dummy = new tnode; 
 dummy->data = -99; 
 dummy->left = dummy->right = NULL; 
 dummy->lth = dummy->rth = 0;} 
void insert(); 
void inorder(); 
void preorder();}; 
void TBT::insert(){ 
 nn = new tnode; 
    cout<<"Enter data = "; 
    cin>>nn->data; 
 nn->left = nn->right = NULL; 
 nn->lth = nn->rth = 0; 
 if(root == NULL){ 
 root = nn; 
 nn->left = dummy; 
 nn->right = dummy; 
 dummy->left = root; 
 dummy->lth = 1; } 
 else{ 
 tnode *cn,*parent; 
 cn = root; 
 while(cn != NULL) { 
 parent = cn; 
 if(nn->data < cn->data) { 
 if(cn->lth == 1) { 
 cn = cn->left; } 
 else { 
 cn = NULL; } } 
 else { 
 if(cn->rth == 1){ 
 cn = cn->right; } 
 else { 
 cn = NULL; } } } 
 if(nn->data < parent->data) { 
 nn->left = parent->left; 
 nn->right = parent; 
 parent->left = nn; 
 parent->lth = 1; } 
 else { 
 nn->right = parent->right; 
 nn->left = parent; 
 parent->right = nn; 
 parent->rth = 1; } } } 
void TBT::inorder(){ 
 tnode *cn; 
 cn = root; 
 while(1) { 
 while(cn->lth == 1) { 
 cn = cn->left; } 
        cout<<cn->data<<" "; 
 while(cn->rth == 0) { 
 if(cn->right ==dummy) { 
 return; } 
 else { 
 cn = cn->right; 
 cout<<cn->data<<" "; } } 
 cn = cn->right; } } 
void TBT::preorder(){ 
 tnode *cn; 
 cn = root; 
 while(1) { 
 while(cn->lth == 1) { 
 cout<<cn->data<<" "; 
 cn = cn->left; } 
 cout<<cn->data<<" "; 
 while(cn->rth == 0) { 
 if(cn->right == dummy) { 
 return; } 
 else { 
 cn = cn->right; } } 
 cn = cn->right; } } 
int main(){ 
 TBT Obj; 
 int ch; 
 cout<<"Enter 1 to insert\nEnter 2 for inorder traversal\nEnter 3 for preorder traversal"<<endl; 
 while(1) { 
 cout<<endl<<"Enter the choice = "; 
 cin>>ch; 
 switch(ch) { 
 case 1: Obj.insert(); 
 break; 
 case 2: cout<<"Inorder traversal is "; 
 Obj.inorder(); 
 cout<<endl; 
 break; 
 case 3: cout<<"Preorder traversal is "; 
 Obj.preorder(); 
 cout<<endl; 
 break; } } } 