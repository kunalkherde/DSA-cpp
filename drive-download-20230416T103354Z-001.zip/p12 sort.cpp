#include <iostream> 
using namespace std; 
class salary_sort{ 
public: 
int n; 
int salary[20]; 
void getSalary(){ 
 int i; 
 cout<<"Enter the no of employees = "; 
 cin>>n; 
 cout<<endl<<"Enter the salary of employees :"<<endl; 
 for(i=0;i<n;i++){ 
 cout<<"Employee "<<i+1<<" = "; 
 cin>>salary[i]; 
 } 
} 
int partition(int m,int p); 
void swap(int i,int j){ 
 int temp; 
 temp = salary[i]; 
 salary[i] = salary[j]; 
 salary[j] = temp; 
} 
void quick_sort(int m,int p){ 
 int j; 
 if(m<p) { 
 j = partition(m,p); 
 quick_sort(m,j-1); 
 quick_sort(j+1,p); 
 } 
} 
void display(){ 
 int i; 
 for(i=0;i<n;i++) { cout<<salary[i]<<" "; } 
 cout<<endl; 
} 
}; 
int salary_sort::partition(int m,int p) 
{ 
 int i=m,j=p; 
 int pivot = salary[m]; 
 do{ 
 while(salary[i]>=pivot) { i++; } 
 while(salary[j]<pivot) { j--; } 
 if(i<j) { swap(i,j); } 
 }while(i<j); 
 swap(m,j); 
 return j; 
} 
int main(){ 
 salary_sort s; 
 s.getSalary(); 
 cout<<endl<<"Salaries before sorting : "<<endl; 
 s.display(); 
 s.quick_sort(0,s.n-1); 
 cout<<endl<<"Salaries after sorting : "<<endl; 
 s.display(); 
 cout<<endl<<"Salaries of top five employee with highest salary :"<<endl; 
 for(int i=0;i<5;i++) 
 { 
 cout<<s.salary[i]<<" "; 
 } 
 return 0; 
} 