#include <bits/stdc++.h> 
using namespace std; 
class infix_postfix 
{ 
 char infix[20]; 
 char postfix[20]; 
 char stack[20]; 
 int top; 
 public : 
 infix_postfix() 
 { 
 top = -1; 
 } 
 void input_infix() 
 { 
 cout<<"Enter Infix Expression : "; 
 cin>>infix; 
 cout<<endl; 
 } 
 int sempty() 
 { 
 if(top==-1) 
 return 1; 
 else 
 return 0; 
 } 
 void push(char x) 
 { 
 top++; 
 stack[top] = x; 
 } 
 char pop() 
 { 
 char x = stack[top]; 
 top--; 
 return x; 
 } 
 void convert_in_post(); 
 int precedence(char x) 
{ 
 if(x == '+' || x == '-') 
 return 1; 
 else if(x == '*' || x == '/') 
 return 2; 
 else if(x == '^') 
 return 3; 
 else 
 return -1; 
} 
void display() 
{ 
 cout<<"Postfix Expression is : "<<postfix; 
} 
}; 
 void infix_postfix :: convert_in_post() 
{ 
 int j = 0; 
 for(int i=0 ; infix[i]!='\0' ; i++ ) 
 { 
 char token = infix[i]; 
 if(token == '(') 
 { 
 push(token); 
 } 
 else if(token == ')') 
 { 
 char x = pop(); 
 while(x != '(') 
 { 
 postfix[j] = x; 
 j++; 
 x = pop(); 
 } 
 } 
 else if(token == '+' || token == '-' || token == '*' || token == '/' || token == '^') 
 { 
 while(precedence(stack[top]) >= precedence(token)) 
 { 
 char x = pop(); 
 postfix[j] = x; 
 j++; 
 } 
 push(token); 
 } 
 else 
 { 
 postfix[j] = token; 
 j++; 
 } 
 } 
 while(!sempty()) 
 { 
 postfix[j] = pop(); 
 j++; 
 } 
 postfix[j] = '\0'; 
} 
int main() 
{ 
 infix_postfix s; 
 s.input_infix(); 
 s.convert_in_post(); 
 s.display(); 
 return 0; 
} 
