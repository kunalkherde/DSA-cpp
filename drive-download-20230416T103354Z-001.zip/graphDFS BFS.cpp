#include <iostream> 
#include <stack> 
#include <queue> 
using namespace std; 
class Graph{ 
 public: 
 int n; 
 int Adj_matrix[10][10]; 
 int visited[10]; 
 Graph(){ 
 int i,j; 
 for(i=0;i<10;i++) { 
 for(j=0;j<10;j++) { 
 Adj_matrix[i][j] = 0; } } } 
void create(); 
void DFS_recursive(int v1); 
void DFS_Non_recursive(); 
void BFS(); 
void Empty_visited(){ 
 for(int i=0;i<10;i++) { 
 visited[i] = 0; } } }; 
void Graph::create(){ 
 int e,v1,v2; 
 cout<<"Enter no of Vertices = "; 
 cin>>n; 
 cout<<"Enter no of Edges = "; 
 cin>>e; 
 for(int i=0 ; i<e ; i++ ) { 
 cout<<"Enter the edge : "<<endl; 
 cout<<"source = "; 
 cin>>v1; 
 cout<<"destination = "; 
 cin>>v2; 
 Adj_matrix[v1][v2] =1; 
 Adj_matrix[v2][v1] = 1; } } 
void Graph::DFS_recursive(int v1){ 
 int v2; 
 cout<<v1<<" "; 
 visited[v1] = 1; 
 for(v2=0;v2<n;v2++) { 
 if(Adj_matrix[v1][v2] == 1 && visited[v2] == 0) { 
 DFS_recursive(v2); } } } 
void Graph::DFS_Non_recursive(){ 
 int v1,v2; 
 stack<int> s; 
 cout<<"Enter Starting vertex = "; 
 cin>>v1; 
 s.push(v1); 
 visited[v1] = 1; 
 while(!s.empty()) { 
 v1 = s.top(); 
 s.pop(); 
 cout<<v1<<" "; 
 for(v2=0;v2<n;v2++) { 
 if(Adj_matrix[v1][v2] == 1 && visited[v2] == 0) { 
 s.push(v2); 
 visited[v2] = 1; } } } 
 cout<<endl; } 
void Graph::BFS(){ 
 int v1,v2; 
 queue<int> q; 
 cout<<"Enter Starting vertex = "; 
 cin>>v1; 
 q.push(v1); 
 visited[v1] = 1; 
 while(!q.empty()) { 
 v1 = q.front(); 
 q.pop(); 
 cout<<v1<<" "; 
 for(v2=0;v2<n;v2++) { 
 if(Adj_matrix[v1][v2] == 1 && visited[v2] == 0) { 
 q.push(v2); 
 visited[v2] = 1; } } } 
 cout<<endl; } 
int main() { 
 int v1; 
 Graph G; 
 char ch,choice; 
 cout<<"Enter 1 to create graph\nEnter 2 for recursive DFS\nEnter 3 for non recursive DFS\nEnter 4 for BFS"<<endl<<endl; 
 do{ 
 cout<<"Enter the choice = "; 
 cin>>ch; 
 switch(ch) { 
 case '1':G.create(); 
 break; 
 case '2':G.Empty_visited(); 
 cout<<"Enter starting vertex = "; 
 cin>>v1; 
 G.DFS_recursive(v1); 
 cout<<endl; 
 break; 
 case '3':G.Empty_visited(); 
 G.DFS_Non_recursive(); 
 break; 
 case '4':G.Empty_visited(); 
 G.BFS(); 
 break; 
 } 
 cout<<endl<<"Do you want to continue ?(y/n) : "; 
 cin>>choice; 
 cout<<endl; 
 } 
 while(choice == 'y'); 
 return 0; 
 } 