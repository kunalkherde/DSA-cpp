#include<iostream>
using namespace std ;
class infixpostfix{
    char infix[20];
    char postfix[20];
    char  stack[30];
    int top;
    infixpostfix()
    {
        top=-1;
    }

    void input_infix(){
        cout<<"Enter infix operation :";
        cin>>infix;
        cout<<endl;

    }
    int isempty(){
        if(top==-1)
            return 1;
        else 
        
            return 0;
    }
    void push(char x){
        top++;

        stack[top]=x;
    }
    void pop(){
        char x = stack[top];
        top--;
    }
};
