#include <iostream> 
using namespace std; 
struct node 
{ 
 int data; 
 node *next; 
}; 
class NODE 
{ 
 node *nn; 
 public: 
 node *header; 
 NODE() 
{ 
 header = NULL; 
} 
 void insertion(); 
 void deletion(); 
 void reverse(node *cn); 
 void search(); 
 void display(); 
}; 
void NODE :: insertion() 
{ 
 int n,count=0; 
 cout<<"Enter position to insert the node = "; 
 cin>>n; 
 node *cn; 
 cn = header; 
 while(cn != NULL) 
 { 
 count++; 
 cn = cn->next; 
 } 
 if(n==1) 
 { 
 nn = new node; 
 cout<<"Enter data = "; 
 cin>>nn->data; 
 nn->next = header; 
 header = nn; 
 } 
 else if(n == count+1) 
 { 
 nn = new node; 
 cout<<"Enter data = "; 
 cin>>nn->data; 
 nn->next=NULL; 
 if(header==NULL) 
 { 
 header = nn; 
 } 
 else 
 { 
 node *cn; 
 cn = header; 
 while(cn->next != NULL) 
 { 
 cn = cn->next; 
 } 
 cn->next = nn; 
 } 
 } 
 else if(n > count+1) 
 { 
 cout<<"Enter new position "<<endl; 
 } 
 else 
 { 
 int i; 
 nn = new node; 
 cout<<"Enter data = "; 
 cin>>nn->data; 
 nn->next = NULL; 
 node *cn; 
 cn = header; 
 for(i=1;i<=n-2;i++) 
 { 
 cn = cn->next; 
 } 
 nn->next = cn->next; 
 cn->next = nn; 
 } 
} 
void NODE :: deletion() 
{ 
 int n,count=0; 
 cout<<"Enter the position of node to delete = "; 
 cin>>n; 
 node *cn; 
 cn = header; 
 while(cn != NULL) 
 { 
 count++; 
 cn = cn->next; 
 } 
 if(n==1) 
 { 
 node *cn; 
 cn = header; 
 header = header->next; 
 delete cn; 
 } 
 else if(n == count) 
 { 
 node *cn,*temp; 
 cn = header; 
 while(cn->next->next != NULL) 
 { 
 cn = cn->next; 
 } 
 temp = cn->next; 
 cn->next = NULL; 
 delete temp; 
 } 
 else if(n > count) 
 { 
 cout<<"Enter new position "<<endl; 
 } 
 else 
 { 
 int i; 
 node *cn,*temp; 
 cn = header; 
 for(i=1;i<=n-2;i++) 
 { 
 cn = cn->next; 
 } 
 temp = cn->next; 
 cn->next = cn->next->next; 
 delete temp; 
 } 
} 
void NODE :: search() 
{ 
 node *cn = header; 
 int key,i=0,flag=0; 
 cout<<"Enter node data you want to search = "; 
 cin>>key; 
 while(cn != NULL) 
 { 
 i++; 
 if(cn->data == key) 
 { 
 flag = i; 
 } 
 cn = cn->next; 
 } 
 if(flag == 0) 
 { 
 cout<<"Node with data "<<key<<" is not present in link list"<<endl; 
 } 
 else 
 { 
 cout<<"Node with data "<<key<<" is present at node number "<<flag<<endl; 
 } 
} 
void NODE :: reverse(node *cn) 
{ 
 if(cn->next != NULL) 
 { 
 reverse(cn->next); 
 } 
 cout<<cn->data<<" "; 
} 
void NODE :: display() 
{ 
 cout<<"Link List is = "; 
 node *cn; 
 cn = header; 
 while(cn != NULL) 
 { 
 cout<<cn->data<<" "; 
 cn = cn->next; 
 } 
 cout<<endl; 
} 
int main() 
{ 
     NODE sll; 
    int ch; 
    cout<<"Enter 1 for insertion\nEnter 2 for deletion\nEnter 3 to reverse\nEnter 4 to display\nEnter 5 to search"<<endl; 
 while(1) 
 { 
 cout<<endl<<"Enter the choice = "; 
 cin>>ch; 
 switch(ch) 
 { 
 case 1 : sll.insertion(); 
 break; 
 case 2 : sll.deletion(); 
 break; 
 case 3 : cout<<"Reverse link List is = "; 
 sll.reverse(sll.header); 
 cout<<endl; 
 break; 
 case 4 : sll.display(); 
 break; 
 case 5 : sll.search(); 
 break; 
 } 
 } 
 return 0; 
} 