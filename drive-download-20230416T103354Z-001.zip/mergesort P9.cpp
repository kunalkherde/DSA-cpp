#include <iostream> 
using namespace std; 
void Merge(int *a,int beg,int mid,int end){ 
 int i,j,k,n1,n2; 
 n1 = mid-beg+1; 
 n2 = end-mid; 
 int LeftArray[n1]; 
 int RightArray[n2]; 
 for(i=0;i<n1;i++) { 
 LeftArray[i] = a[beg+i]; } 
 for(j=0;j<n2;i++) { 
 RightArray[j] = a[mid+1+j]; } 
 i=0; 
 j=0; 
 k=beg; 
 while(i<n1 && j<n2) { 
 if(LeftArray[i] <= RightArray[j]) { 
 a[k] = LeftArray[i]; 
 i++; } 
 else { 
 a[k] = RightArray[j]; 
 j++; } 
 k++; } 
 while(i<n1) { 
 a[k] = LeftArray[i]; 
 i++; 
 k++; 
 } 
 while(j<n2) 
 { 
 a[k] = RightArray[j]; 
 j++; 
 k++; } } 
void Merge_sort(int *a,int beg,int end){ 
 int mid; 
 if(beg<end) { 
 mid = beg+(end-beg)/2; 
 Merge_sort(a,beg,mid); 
 Merge_sort(a,mid+1,end); 
 Merge(a,beg,mid,end); }} 
void display(int *a,int size){ 
 int i; 
 for(i=0;i<size;i++) { 
 cout<<a[i]<<" "; } } 
int main() { 
 int i,n; 
 cout<<"Enter the no of employees = "; 
 cin>>n; 
 int salary[n]; 
 cout<<endl<<"Enter the salary : "<<endl; 
 for(i=0;i<n;i++) { 
 cout<<"Employee "<<i+1<<" = "; 
 cin>>salary[i]; } 
 cout<<endl<<"Salaries of employee before sorting : "<<endl; 
 display(salary,n); 
 Merge_sort(salary,0,n-1); 
 cout<<endl<<"Salaries of employee after sorting : "<<endl; 
 display(salary,n); 
 return 0; 
} 