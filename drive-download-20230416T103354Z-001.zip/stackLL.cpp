#include <iostream> 
using namespace std; 
struct node 
{ 
 int data; 
 node *next; 
}; 
class linked_stack 
{ 
 node *nn; 
 node *top; 
public : 
 linked_stack() 
 { 
 top = NULL; 
 } 
 int isempty(); 
 void push(); 
 int pop(); 
 int gettop(); 
 void display(); 
}; 
class linked_queue 
{ 
 node *nn; 
 node *front,*rear; 
public : 
 linked_queue() 
 { 
 front = NULL; 
 rear = NULL; 
 } 
 void enqueue(); 
 int dequeue(); 
 int getfront(); 
 int getrear(); 
 void display(); 
}; 
int linked_stack::isempty() 
{ 
 if(top == NULL) 
 return 1; 
 else 
 return 0; 
} 
void linked_stack::push() 
{ 
 nn = new node; 
 cout<<"Enter data = "; 
 cin>>nn->data; 
 nn->next = NULL; 
 if(isempty()) 
 { 
 top = nn; 
 } 
 else 
 { 
 nn->next = top; 
 top = nn; 
 } 
} 
int linked_stack::pop() 
{ 
 if(isempty()) 
 { 
 cout<<"Stack is empty"<<endl; 
 return 0; 
 } 
 else 
 { 
 node *cn = top; 
 top = top->next; 
 int x = cn->data; 
 delete cn; 
 return x; 
 } 
} 
int linked_stack::gettop() 
{ 
 if(isempty()) 
 { 
 cout<<"Stack is empty"<<endl; 
 return 0; 
 } 
 else 
 { 
 int x = top->data; 
 return x; 
 } 
} 
void linked_stack::display() 
{ 
 if(isempty()) 
 { 
 cout<<"Stack is empty"<<endl; 
 } 
 else 
 { 
 node *cn = top; 
 while(cn != NULL) 
 { 
 cout<<cn->data<<" "; 
 cn = cn->next; 
 } 
 cout<<endl; 
 } 
} 
void linked_queue::enqueue() 
{ 
 nn = new node; 
 cout<<"Enter data = "; 
 cin>>nn->data; 
 nn->next = NULL; 
 if(front == NULL) 
 { 
 front = nn; 
 rear = nn; 
 } 
 else 
 { 
 rear->next = nn; 
 rear = nn; 
 } 
} 
int linked_queue::dequeue() 
{ 
 if(front == NULL) 
 { 
 cout<<"Queue is empty"<<endl; 
 return 0; 
 } 
 else 
 { 
 node *cn = front; 
 front = front->next; 
 int x = cn->data; 
 delete cn; 
 return x; 
 } 
} 
void linked_queue::display() 
{ 
 if(front == NULL) 
 { 
 cout<<"Queue is empty"<<endl; 
 } 
 else 
 { 
 node *cn = front; 
 while(cn != NULL) 
 { 
 cout<<cn->data<<" "; 
 cn = cn->next; 
 } 
 cout<<endl; 
 } 
} 
int linked_queue::getfront() 
{ 
 if(front != NULL) 
 { 
 return front->data; 
 } 
 else 
 { 
 cout<<"Queue is empty"<<endl; 
 return 0; 
 } 
} 
int linked_queue::getrear() 
{ 
 if(rear != NULL) 
 { 
 return rear->data; 
 } 
 else 
 { 
 cout<<"Queue is empty"<<endl; 
 return 0; 
 } 
} 
int main() { 
 int ch; 
 cout<<"Enter 1 to implement stack\nEnter 2 to implement queue"<<endl; 
 cout<<endl<<"Enter The Choice = "; 
 cin>>ch; 
 cout<<endl; 
 if(ch==1) 
 { 
 linked_stack s; 
 int ch1; 
 cout<<"Enter 1 to push data\nEnter 2 to pop data\nEnter 3 to get top value\nEnter 4 to display stack element"<<endl; 
 while(1) 
 { 
 cout<<endl<<"Enter The Choice = "; 
 cin>>ch1; 
 switch(ch1) 
 { 
 case 1: s.push(); 
 break; 
 case 2: int x; 
 x = s.pop(); 
 if(x==0) 
 { 
 break; 
 } 
 else 
 { 
 cout<<"poped value is = "<<x<<endl; 
 break; 
 } 
 case 3: int y; 
 y = s.gettop(); 
 if(y==0) 
 { 
 break; 
 } 
 else 
 { 
 cout<<"top value is = "<<y<<endl; 
 break; 
 } 
 case 4:s.display(); 
 break; 
 } 
 } 
 } 
else 
{ 
 linked_queue q; 
 int ch2; 
 cout<<"Enter 1 to insert data(Enqueue)\nEnter 2 to delete data(Dequeue)\nEnter 3 to get front value\nEnter 4 to get rear value\nEnter 5 to display queue element"<<endl; 
 while(1) 
 { 
 cout<<endl<<"Enter The Choice = "; 
 cin>>ch2; 
 switch(ch2) 
 { 
 case 1: q.enqueue(); 
 break; 
 case 2: int x; 
 x = q.dequeue(); 
 if(x==0) 
 { 
 break; 
 } 
 else 
 { 
 cout<<"deleted value is = "<<x<<endl; 
 break; 
 } 
 case 3: int y; 
 y = q.getfront(); 
 if(y==0) 
 { 
 break; 
 } 
 else 
 { 
 cout<<"front value is = "<<y<<endl; 
 break; 
 } 
 case 4: int z; 
 z = q.getrear(); 
 if(z==0) 
 { 
 break; 
 } 
 else 
 { 
 cout<<"rear value is = "<<z<<endl; 
 break; 
 } 
 case 5:q.display(); 
 break; 
 } 
 } 
 } 
 return 0; 
} 