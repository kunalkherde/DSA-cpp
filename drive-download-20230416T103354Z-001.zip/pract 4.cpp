#include<iostream>
using namespace std ;

// create a node structure 

struct node
{
    int data ;
    node*next;
};
// create class stack
class stack{
    private:
    node*nn=nullptr;
    node*top=nullptr;

    public:
//declare methods of stack 

    void push(){
        nn=nullptr;
        nn=new node;
        cout<<"Enter the data in stack : ";
        cin>>nn->data ;

        nn->next=top;
        top=nn;


    }

    void pop(){
        node*temp;
        temp=top;

        while (top!=nullptr)
        {
            top=top->next;

            delete temp;
            temp=nullptr;
        }
        
    }
    void dispiay(){
        node*nn;
        nn=top;
        while (nn!=nullptr)
        {
            cout<<nn->data<<"";
            nn=nn->next;
        }
        
    }
};

class queue{
    private:
    node*front=nullptr;
    node*rear=nullptr;
    node*nn=nullptr;

    public:


    void enqueue(){
        nn=nullptr;
        nn=new node;

        cout<<"Enter the data ";
        cin>>nn->data;

        if(front==nullptr && rear==nullptr){
            front=nn;
            rear=nn;
        }

        else{
            rear->next=nn;
            rear=rear->next;
        }
    }

    void dequeue(){

        if(front==nullptr && rear==nullptr){
            cout<<"queue is empty";

        }
        else if(front->next!=nullptr){
            node*temp=front;
            front=front->next;
            delete temp;

        }
        else{
            delete front;
            front=nullptr;
            rear=nullptr;
        }
    }

    void display(){
        node*cn=front;
        if(cn!=nullptr){
            cout<<cn->data;
            cn=cn->next;
        }
    }
};

int main(){
    char choice;

    cout<<"STACK AND QUEUE OPERATION"<<endl;
    cout<<"Enter your choice \n"<<"1. stack operation \n"<<"2. queue operation \n"<<"3. Exit \n";
    cin>>choice;

    switch (choice)
    {
    case '1':{
        stack s;
        char stack_operation_choice=0;
        while (stack_operation_choice!=4)
        {
            cout<<"STACK OPERATION "<<endl<<"\n 1.push \n"<<"\n 2.pop \n"<<"\n 3.display\n"<<"\n 4.exit\n";
            cin>>stack_operation_choice;

            switch (stack_operation_choice)
            {
            case '1':
                s.push();
                s.dispiay();
                break;
            case '2':
                s.pop();
                s.dispiay();
                break;
            case '3':
                s.dispiay();
            case '4':
                return 0;
            
            }

        }
        
    }

    case'2':{
        queue q;
        char queue_operation_choice;

        cout<<"QUEUE OPERATION"<<endl<<"\n 1. Enque \n"<<"\n 2. dequeue \n"<<"\n 3.display\n";
        cin>>queue_operation_choice;

        switch (queue_operation_choice)
        {
        case '1':
            q.enqueue();
            q.display();
            break;
        case '2':
            q.dequeue();
            q.display();
            break;
        case '3':
            q.display();
            break;
        case '4':
            return 0;
        
        }
    }
    }
return 0;
}


