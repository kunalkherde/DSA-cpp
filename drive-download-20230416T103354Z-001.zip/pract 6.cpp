#include<iostream> 
using namespace std; 
struct tnode{ 
 int data; 
 tnode *L,*R; 
}; 
class AVL{ 
 tnode *root; 
public: 
 AVL(){ root = NULL;} 
 void create(); 
 void display(); 
 tnode *insert(tnode *,int); 
 void inorder(tnode *); 
 void preorder(tnode *); 
 int height(tnode *); 
 int MAX(int,int);
 tnode * LL(tnode *); 
 tnode * RR(tnode *); 
 tnode * LR(tnode *); 
 tnode * RL(tnode *);}; 
tnode * AVL :: LL(tnode *parent){ 
tnode *temp; 
temp= parent->L; 
parent->L = temp->R; 
temp->R = parent; 
return temp;} 
tnode * AVL :: RR(tnode *parent){ 
tnode *temp; 
temp = parent->R; 
parent->R = temp->L; 
temp->L = parent; 
return temp; 
} 
tnode * AVL :: LR(tnode *parent){ 
parent->L = RR(parent->L); 
parent = LL(parent); 
return parent;} 
tnode * AVL :: RL(tnode *parent){ 
 parent->R = RR(parent->R); 
 parent = LL(parent); 
 return parent; 
} 
int AVL :: MAX(int a, int b){ 
    if(a>b) 
        return a; 
    else 
        return b;} 
int AVL :: height(tnode *temp ){ 
if(temp == NULL){return -1;} 
if(temp->L == NULL && temp->R == NULL){return 0;} 
return(1 + MAX(height(temp->L),height(temp->R))); 
} 
void AVL :: inorder(tnode *temp){ 
 if(temp != NULL){ 
inorder(temp->L); 
cout<<temp->data<<" "; 
inorder(temp->R);} 
} 
tnode * AVL :: insert(tnode *temp,int val){ 
 if(temp == NULL){ 
 temp = new tnode; 
 temp->data = val; 
 temp->L = temp->R = NULL;} 
 else{ 
 if(val < temp->data){ 
 temp->L = insert(temp->L,val); 
 if( ( height(temp->L) - height(temp->R)==2) ){ 
 if(val < temp->L->data) 
 temp = LL(temp); 
 else{temp = LR(temp);}}} 
else{ temp->R = insert(temp->R,val); 
 if( (height(temp->L) - height(temp->R)==-2) ){ 
 if(val > temp->R->data){temp = RR(temp);} 
 else{temp = RL(temp);}}}} 
return temp;} 
void AVL :: display(){cout<<"\n Dictionary Data in Ascending order :"<<endl; 
 inorder(root); 
 cout<<"\n Preorder : "; 
 preorder(root);} 
void AVL :: create(){int val; 
 char ch; 
 do{cout<<"Enter Data = "; 
 cin>>val; 
 root = insert(root,val); 
 cout<<"Do yo want to Continue : "; 
 cin>>ch; 
 }while(ch=='y');} 
void AVL :: preorder(tnode *temp){ 
 if(temp != NULL){ 
 cout<<temp->data<<" "; 
 preorder(temp->L); 
 preorder(temp->R);}} 
int main(){ 
AVL t; 
 t.create(); 
 t.display(); 
 return 0; 
} 