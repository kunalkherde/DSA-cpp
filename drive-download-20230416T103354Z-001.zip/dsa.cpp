#include<iostream>
using namespace std ;

struct node{
   node*next;
   int data ;
};

class LL{
   private:
   node*head=0;
   public:
   void insert(){
      node*newnode;
      newnode=new node();
      int n;
      cout<<"Enter the data in node :";
      cin>>n;

      newnode->data=n;
      newnode->next=head;
      head=newnode;
   }

   void delatbeg(){
      node*p=head;
      head=p->next;
      delete(p);
   }

   void insertAtposition(){
      int n,no,i;
      node*newnode;
      newnode=new node();
      cout<<"Enter the data :";
      cin>>n;
      cout<<"Enter the position of an emement ";
      cin>>no;
      node*temp;
      node*storenext;
      for(i=1;i<no-1;i++){
         temp=temp->next;
      }
      storenext=temp->next;
      temp->next=newnode;
      newnode->next=storenext;
   }
   void delatmiddle(){
      int n,i;
      node*temp,*storenext;
      cout<<"Enter postition ofto delete an element";
      cin>>n;
      for(i=1;i<n-1;i++){
         temp=temp->next;
      }

      storenext=temp->next;
      temp->next=temp->next->next;
      delete(storenext);
   }
   void display(){
       node*temp=head;
       while(temp!=NULL){
           cout<<temp->data;
           temp=temp->next;
       }
   }
};
int main(){
   LL x;
   int ch,a;
   do{
       cout<<"1. Enter 1 for insert data at beg"<<endl<<"2. Enter for delatbeg"<<"3. Enter 3 for insertAtposition data "<<endl<<"4. enter 4 for delatbeg"<<endl<<"5.press 5 for display"<<endl;
       cin>>ch;
   
    switch(ch){
        case 1:
        x.insert();
        break;
        
        case 2:
        x.delatbeg();
        break;
        
        case 3:
        x.insertAtposition();
        break;
        
        case 4:
        x.delatbeg();
        break;
        
        case 5:
        x.display();
        break;
        
        default:
        cout<<"invalid output ";

    }
    cout<<"press Y or y to continue";
    cin>>a;
    
    }while(a=='Y'| a=='y');
   
}
